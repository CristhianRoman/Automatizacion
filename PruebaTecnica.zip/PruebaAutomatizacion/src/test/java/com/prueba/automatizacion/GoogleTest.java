package com.prueba.automatizacion;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleTest {
	
	private WebDriver driver;
	
	@Before
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com.co/");
		
	}
	
	@Test
	public void testGoogle() {
		
		WebElement box = driver.findElement(By.name("q"));
		
		box.clear();
		box.sendKeys("pruebaz");
		box.submit();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		System.out.println("el tama�o  es:"+  driver.findElements(By.className("g")).size());
		assertTrue(driver.findElements(By.className("g")).size()>6);
	}
	
	@After
	public void tearDown() {
		
		driver.quit();
	}

}
